<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            background-color: LightSkyBlue;
        }
        
        form {
            margin: 0 auto;
            width: 30%;
            background-color: white;
            padding: 50px;
            border-radius: 5px;
            box-shadow: 0px 0px 5px 0px rgba(0,0,0,0.2);
        }

        input[type=text], input[type=number], select {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        
        input[type=submit] {
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            border: none;
            border-radius: 3px; 
            padding-right: 70px;
            cursor: pointer;    
        }
        
        input[type=reset] {
            background-color: #00CED1;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            border: none;
            border-radius: 3px;
            padding: 10px 20px;
            cursor: pointer;
        }
        
        input[type=submit]:hover {
            background-color: #45a049;
        }
        
        input[type=reset]:hover {
            background-color: #4169E1;
        }
        
        .buttons {
            display: flex;
            justify-content: space-between;
            width: 100%;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            text-align: left;
            padding: 8px;
            border: 1px solid #ddd;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }
    </style>
</head>
<body>
    <table>
        <tr>
            <th>ID  :</th>
            <th>Nom  :</th>
            <th>Prenom :</th>
            <th>Numero telephone :</th>
            <th>Adresse :</th>
            <th>Sexe :</th>
            <th>Résultat :</th>
         
        </tr>
        <?php 

         include_once "../repository/Fonction.php";

        $edb = new Fonction();

        $Personne = $edb->GetAllPersonne();

           /* echo "<table>
            <tr>
               <th>ID  :</th>
               <th>Nom  :</th>
               <th>Prenom :</th>
               <th>Numero telephone :</th>
               <th>Adresse :</th>
               <th>Sexe :</th>
               <th>Résultat :</th>
            </tr>";*/

   foreach ($Personne as $personne) {
       echo "<tr>
               <td>$personne[0]</td>
               <td>$personne[1]</td>
               <td>$personne[2]</td>
               <td>$personne[3]</td>
               <td>$personne[4]</td>
               <td>$personne[5]</td>
               <td>$personne[6]</td>
           </tr>";
   }

   echo "</table>";

?>

